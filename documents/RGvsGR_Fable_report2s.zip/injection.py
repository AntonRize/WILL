"""Injection-recovery tests answering the three concerns:
A) How much of the WILL-vs-GR model difference is drift-shaped? (weighted projection)
B) Truth = pure GR (+ injected instrumental drift) + noise -> fit both 9-param models.
   If WILL 'wins' on GR-truth data only when drift is present, mechanism proven.
C) Truth = WILL (+ same drift) + noise -> fit both WITH nuisance terms.
   If WILL still wins when it is true, the nuisance method does not erase real signals.
"""
import numpy as np, sys
from scipy.optimize import minimize
from models import (model_gr_timelinear, model_will, t_a, t_r,
                    x_err, y_err, rv_err, x_obs, y_obs, rv_obs, BOUNDS)
from validate_followups import A, AW, ATA, W, inames, t_ref, inst
from gr_integrated_lib import integrate_orbit, model_integrated

pw = np.load('best_will.npy'); pg = np.load('best_gr.npy'); pi = np.load('best_integrated.npy')
MODE = sys.argv[1]

# ---------- A) projection of the model-difference onto the systematics subspace ----------
if MODE == 'A':
    for tag, (ya, yb) in {
        'WILLbest - timelinearGRbest': (model_will(pw, t_a, t_r), model_gr_timelinear(pg, t_a, t_r)),
        'WILLbest - integratedGRbest': (model_will(pw, t_a, t_r), model_integrated(pi, t_a, t_r))}.items():
        d = np.concatenate([ya[0]-yb[0], ya[1]-yb[1], ya[2]-yb[2]])
        c = np.linalg.solve(ATA, AW.T @ d)
        frac = (d @ (W * (A @ c))) / (d @ (W * d))
        print(f"  {tag}: {100*frac:.1f}% of the weighted squared difference lies in the "
              f"offset+drift+RVoffset subspace")

# ---------- shared synthetic machinery ----------
DRIFT1 = dict(x0=-1.0e-3, y0=+0.9e-3, vx0=+0.08e-3, vy0=+0.20e-3)     # arcsec, arcsec/yr (data-scale)
DRIFT2 = dict(x0=+0.5e-3, y0=-0.8e-3, vx0=+0.15e-3, vy0=-0.10e-3)     # different direction
RVOFF  = {'VLT': +15.0, 'NIFS': -12.0, 'NIRC2': -60.0, 'IRCS': +18.0, 'NIRSPEC': +10.0}

def add_syst(xs, ys, rv, dr):
    ta_yr = (t_a - t_ref)/365.25
    xs = xs + dr['x0'] + dr['vx0']*ta_yr
    ys = ys + dr['y0'] + dr['vy0']*ta_yr
    rv = rv + np.array([RVOFF.get(k, 0.0) for k in inst])
    return xs, ys, rv

def chi2_against(model_fn, p, target, **kw):
    xm, ym, rvm = model_fn(p, t_a, t_r, **kw)
    return (np.sum(((target[0]-xm)/x_err)**2) + np.sum(((target[1]-ym)/y_err)**2)
            + np.sum(((target[2]-rvm)/rv_err)**2))

def chi2_against_nuis(model_fn, p, target, **kw):
    xm, ym, rvm = model_fn(p, t_a, t_r, **kw)
    resid = np.concatenate([target[0]-xm, target[1]-ym, target[2]-rvm])
    c = np.linalg.solve(ATA, AW.T @ resid)
    rr = resid - A @ c
    return float(np.sum(W * rr**2))

def fit(obj, p0, it=3000):
    r1 = minimize(obj, p0, method='Nelder-Mead', options={'maxiter': it, 'fatol': 1e-7})
    r2 = minimize(obj, r1.x, method='Nelder-Mead', options={'maxiter': 900})
    return min([r1, r2], key=lambda r: r.fun).fun

rng = np.random.default_rng(int(sys.argv[2]) if len(sys.argv) > 2 else 2026)
def noisy(t):
    return (t[0] + rng.normal(0, x_err), t[1] + rng.normal(0, y_err), t[2] + rng.normal(0, rv_err))

# ---------- B) truth = integrated GR ----------
if MODE == 'B':
    sp = integrate_orbit(pi)
    truth = model_integrated(pi, t_a, t_r, state_pack=sp)
    for lab, dr in [('no systematics (control)', None), ('drift set 1', DRIFT1), ('drift set 2', DRIFT2)]:
        base = truth if dr is None else add_syst(*truth, dr)
        ds = []
        for k in range(3):
            tgt = noisy(base)
            cw = fit(lambda p: chi2_against(model_will, p, tgt, f_source='will', rv_mode='mult'), pw)
            cg = fit(lambda p: chi2_against(model_gr_timelinear, p, tgt, f_source='gr1pn'), pg)
            ds.append(cg - cw)
            print(f"    GR-truth, {lab}, realization {k}: chi2 WILL {cw:7.1f}  GR {cg:7.1f}  Delta(GR-WILL) {cg-cw:+7.1f}")
        print(f"  GR-truth, {lab}: mean Delta(GR-WILL) = {np.mean(ds):+7.1f}")

# ---------- C) truth = WILL ----------
if MODE == 'C':
    truth = model_will(pw, t_a, t_r, f_source='will', rv_mode='mult')
    for lab, dr in [('drift set 1', DRIFT1)]:
        base = add_syst(*truth, dr)
        for k in range(3):
            tgt = noisy(base)
            cwN = fit(lambda p: chi2_against_nuis(model_will, p, tgt, f_source='will', rv_mode='mult'), pw)
            cgN = fit(lambda p: chi2_against_nuis(model_gr_timelinear, p, tgt, f_source='gr1pn'), pg)
            cw9 = fit(lambda p: chi2_against(model_will, p, tgt, f_source='will', rv_mode='mult'), pw)
            cg9 = fit(lambda p: chi2_against(model_gr_timelinear, p, tgt, f_source='gr1pn'), pg)
            print(f"    WILL-truth+drift, real. {k}: 9p WILL {cw9:7.1f} GR {cg9:7.1f} D {cg9-cw9:+6.1f} | "
                  f"+nuis WILL {cwN:7.1f} GR {cgN:7.1f} D {cgN-cwN:+6.1f}")

# ---------- D) truth = integrated GR + drift, fit both WITH nuisance ----------
if MODE == 'D':
    sp = integrate_orbit(pi)
    truth = model_integrated(pi, t_a, t_r, state_pack=sp)
    base = add_syst(*truth, DRIFT1)
    for k in range(3):
        tgt = noisy(base)
        cwN = fit(lambda p: chi2_against_nuis(model_will, p, tgt, f_source='will', rv_mode='mult'), pw)
        cgN = fit(lambda p: chi2_against_nuis(model_gr_timelinear, p, tgt, f_source='gr1pn'), pg)
        print(f"    GR-truth+drift, real. {k}: +nuis WILL {cwN:7.1f}  GR {cgN:7.1f}  Delta {cgN-cwN:+6.1f}")
